"use client";

import { useState } from "react";
import { HintPanel } from "./hint-panel";
import { verifyStage } from "./lab-ui";

import { Icon } from "@/components/ui/icon";
const CONTAINMENT_STEPS = [
  { id: "preserve", label: "Preserve forensic evidence — export SIEM/EDR logs before any changes" },
  { id: "block_c2", label: "Block identified C2 server at perimeter firewall — terminate active beacon" },
  { id: "isolate", label: "Isolate finance-ws01 from the network — quarantine the compromised host" },
  { id: "reset_creds", label: "Reset finance.user credentials — invalidate compromised account" },
  { id: "notify", label: "Notify CISO and legal — mandatory for potential data breach" },
  { id: "reimage", label: "Reimage finance-ws01 immediately without forensic capture" },
  { id: "shutdown", label: "Shut down all company systems — halt all business operations" },
] as const;

type StepId = (typeof CONTAINMENT_STEPS)[number]["id"];

export function SocTask2Containment({ labId, alreadyDone }: { labId: string; alreadyDone: boolean }) {
  const [selected, setSelected] = useState<Set<StepId>>(new Set());
  const [submitted, setSubmitted] = useState(alreadyDone);
  const [wrong, setWrong] = useState<string[]>([]);
  const [pending, setPending] = useState(false);

  function toggle(id: StepId) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setPending(true);
    try {
      // Which steps are the right ones is decided on the server. Marking them
      // `required: true` in this array put the answer in the page for anyone who
      // opened devtools, and posting the completion straight afterwards meant a
      // wrong plan could be recorded as a right one.
      const verdict = await verifyStage(labId, "task_2", [...selected].join(", "));
      if (verdict.correct) {
        setSubmitted(true);
        setWrong([]);
      } else {
        setWrong(["That plan isn't right yet — you have either missed a required step or included one that destroys evidence or halts the business unnecessarily."]);
      }
    } finally {
      setPending(false);
    }
  }

  if (submitted) {
    return (
      <div className="rounded-lg border border-sage-500/30 bg-sage-500/5 p-4 text-sm">
        <p className="text-sage-500 font-medium mb-2">Containment plan accepted <Icon name="check" size={14} className="inline-block shrink-0" /></p>
        <p className="text-zinc-400">Correct sequence: Preserve evidence → Block C2 + Isolate host → Reset credentials → Notify CISO/Legal</p>
        <p className="text-zinc-500 mt-2">Proceed to Task 3 — threat hunt for lateral movement.</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="rounded-lg border border-blue-500/20 bg-blue-500/5 p-4 text-sm">
        <p className="text-blue-400 font-medium mb-1">New intelligence</p>
        <p className="text-zinc-300">The attacker is actively beaconing every 5 minutes. The compromised user&apos;s session is still active on the affected workstation. You have a 10-minute window before they escalate privileges further. Select all correct containment actions — avoid steps that would destroy evidence or cause unnecessary business disruption.</p>
      </div>

      <form onSubmit={submit} className="space-y-4">
        <p className="text-sm font-medium text-zinc-300">Select all appropriate containment steps:</p>
        <div className="space-y-2">
          {CONTAINMENT_STEPS.map((step) => (
            <label
              key={step.id}
              className={`flex items-start gap-3 rounded-lg border p-3 cursor-pointer transition ${
                selected.has(step.id)
                  ? "border-sage-500/40 bg-sage-500/5"
                  : "border-white/8 hover:border-white/20"
              }`}
            >
              <input
                type="checkbox"
                checked={selected.has(step.id)}
                onChange={() => toggle(step.id)}
                className="mt-0.5 accent-emerald-500 shrink-0"
              />
              <span className="text-sm text-zinc-300">{step.label}</span>
            </label>
          ))}
        </div>

        {wrong.length > 0 && (
          <div className="rounded border border-red-500/30 bg-red-500/5 p-3 text-sm text-red-400">
            {wrong.map((w) => <p key={w} className="flex items-center gap-1"><Icon name="cross" size={12} /> {w}</p>)}
          </div>
        )}

        <HintPanel labId={labId} stage="task_2" />

        <button
          type="submit"
          disabled={pending || selected.size === 0}
          className="rounded bg-sage-500 px-5 py-2.5 text-sm font-medium text-black hover:bg-sage-700 hover:text-white disabled:opacity-50"
        >
          {pending ? "Submitting…" : "Submit containment plan"}
        </button>
      </form>
    </div>
  );
}
