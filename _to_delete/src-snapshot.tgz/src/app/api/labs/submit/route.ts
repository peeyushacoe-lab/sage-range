import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getOrCreateAppUser } from "@/lib/current-user";
import { rateLimit } from "@/lib/rate-limit";
import { audit } from "@/lib/audit";
import { coinsForPoints } from "@/lib/soc-league";
import { checkDailyHuntCompletion } from "@/lib/daily-hunt";
import { recordEvidence, labTacticsAndTechniques } from "@/lib/evidence";

const Body = z.object({
  labSlug: z.string().min(1),
  flag: z.string().min(1).max(512),
});

export async function POST(req: Request) {
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "bad_request" }, { status: 400 });

  const user = await getOrCreateAppUser();
  if (!user) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  // 15 flag attempts per lab per 10 minutes
  const rl = await rateLimit(`flag:${user.id}:${parsed.data.labSlug}`, { max: 15, windowSec: 600 });
  if (!rl.allowed) {
    return NextResponse.json(
      { error: "Too many attempts. Wait a few minutes before trying again." },
      { status: 429, headers: { "Retry-After": "600" } }
    );
  }

  const lab = await db.lab.findUnique({
    where: { slug: parsed.data.labSlug },
    include: { flags: true },
  });
  if (!lab || !lab.published) return NextResponse.json({ error: "not_found" }, { status: 404 });

  const submitted = parsed.data.flag.trim();
  const matched = lab.flags.find((f) =>
    f.caseSensitive ? f.value === submitted : f.value.toLowerCase() === submitted.toLowerCase()
  );

  if (!matched) {
    await db.attempt.upsert({
      where: { userId_labId: { userId: user.id, labId: lab.id } },
      create: { userId: user.id, labId: lab.id, status: "IN_PROGRESS", labVersion: lab.version },
      update: {},
    });
    // Logged on failure too (not just success) so instructor analytics can
    // compute first-attempt success rate and find common failure points —
    // see src/lib/insights/instructor-analytics.ts.
    audit({ actorId: user.id, action: "FLAG_SUBMIT", target: parsed.data.labSlug, req, meta: { correct: false } });
    return NextResponse.json({ correct: false });
  }

  const existing = await db.attempt.findUnique({
    where: { userId_labId: { userId: user.id, labId: lab.id } },
  });
  if (existing?.status === "SOLVED") {
    return NextResponse.json({ correct: true, alreadySolved: true });
  }

  const startedAt = existing?.startedAt ?? new Date();
  const solvedAt = new Date();
  const timeTakenSec = Math.floor((solvedAt.getTime() - startedAt.getTime()) / 1000);
  const awardPoints = user.role === "STUDENT" ? matched.points : 0;

  const [attempt] = await db.$transaction([
    db.attempt.upsert({
      where: { userId_labId: { userId: user.id, labId: lab.id } },
      create: {
        userId: user.id,
        labId: lab.id,
        status: "SOLVED",
        score: awardPoints,
        labVersion: lab.version,
        startedAt,
        solvedAt,
        timeTakenSec,
      },
      update: {
        status: "SOLVED",
        score: awardPoints,
        solvedAt,
        timeTakenSec,
      },
    }),
    db.user.update({
      where: { id: user.id },
      data: {
        skillScore: { increment: awardPoints },
        xp: { increment: awardPoints },
        coins: { increment: coinsForPoints(awardPoints) },
      },
    }),
  ]);

  // Emit evidence for the unified skill spine — best-effort, never blocks the
  // flag path. skillPoints mirrors the award already granted above, so the
  // profile derived in src/lib/skill-engine.ts matches the live skillScore
  // while the spine is validated before anything is switched to derive from it.
  try {
    const { tactics, techniques } = labTacticsAndTechniques(lab.slug);
    await recordEvidence({
      userId: user.id,
      activity: "LAB",
      sourceId: attempt.id,
      result: "SOLVED",
      skillPoints: awardPoints,
      slug: lab.slug,
      title: lab.title,
      difficulty: lab.difficulty,
      score: awardPoints,
      maxScore: matched.points,
      attempts: (existing?.wrongAttempts ?? 0) + 1,
      timeSec: timeTakenSec,
      tactics,
      techniques,
    });
  } catch {
    // Additive telemetry — a failure here must not fail the solve.
  }

  // Daily Hunt bonus — best-effort, never blocks the main flag-submission path
  try {
    await checkDailyHuntCompletion(user.id, lab.id, solvedAt);
  } catch {
    // ignore
  }

  // Award competition points for CTF-style flag submission (full-lab score, difficulty-weighted)
  if (user.role === "STUDENT") {
    try {
      const DIFFICULTY_WEIGHT: Record<string, number> = { EASY: 1.0, MEDIUM: 1.5, HARD: 2.0, INSANE: 3.0 };
      const weight = DIFFICULTY_WEIGHT[lab.difficulty] ?? 1.0;
      const competitionPoints = Math.round(matched.points * weight);

      const now = new Date();
      const activeEntries = await db.competitionEntry.findMany({
        where: {
          userId: user.id,
          competition: {
            published: true,
            startDate: { lte: now },
            endDate: { gte: now },
          },
        },
        include: { competition: true },
      });
      for (const entry of activeEntries) {
        const slugs = entry.competition.labSlugs as string[];
        if (slugs.includes(lab.slug)) {
          await db.competitionEntry.update({
            where: { id: entry.id },
            data: { score: { increment: competitionPoints } },
          });
        }
      }
    } catch {
      // Never fail the flag submission due to competition scoring errors
    }
  }

  audit({ actorId: user.id, action: "FLAG_SUBMIT", target: parsed.data.labSlug,
    req, meta: { correct: true, points: awardPoints } });
  return NextResponse.json({ correct: true, points: awardPoints });
}
